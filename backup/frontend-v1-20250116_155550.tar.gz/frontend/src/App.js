import React, { useState, useEffect, useRef } from 'react';

const MessageRotator = () => {
  const [inputValue, setInputValue] = useState('');
  const inputValueRef = useRef(inputValue);

  useEffect(() => {
    inputValueRef.current = inputValue;
  }, [inputValue]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      console.log(inputValueRef.current);
    }, 10000); // Update every 10 seconds

    return () => clearInterval(intervalId); // Cleanup on unmount
  }, []);
  
const submitHandler = ()=>{
  console.log("first")
}

  return (
    <div>
      <textarea
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
      />
      <button onClick={submitHandler}>Submit</button>
    </div>
  );
};

export default MessageRotator;
